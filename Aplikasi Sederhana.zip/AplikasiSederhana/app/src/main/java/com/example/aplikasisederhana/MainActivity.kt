package com.example.aplikasisederhana

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.aplikasisederhana.ui.theme.AplikasiSederhanaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AplikasiSederhanaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    OWASPTop10Content()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OWASPTop10Content() {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "OWASP Top 10 2023",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Daftar OWASP Top 10
        OWASPItem(
            number = "1",
            title = "Broken Access Control",
            description = "Ketika pengguna dapat mengakses data atau fungsi di luar batas yang seharusnya. Contoh: Mengubah URL untuk mengakses data pengguna lain."
        )

        OWASPItem(
            number = "2",
            title = "Cryptographic Failures",
            description = "Kegagalan dalam proteksi data sensitif. Contoh: Penyimpanan password tanpa enkripsi atau menggunakan algoritma yang lemah."
        )

        OWASPItem(
            number = "3",
            title = "Injection",
            description = "Serangan dengan menyisipkan kode berbahaya. Contoh: SQL injection, NoSQL injection, LDAP injection."
        )

        OWASPItem(
            number = "4",
            title = "Insecure Design",
            description = "Kelemahan karena desain sistem yang tidak aman. Contoh: Tidak ada rate limiting untuk mencegah brute force."
        )

        OWASPItem(
            number = "5",
            title = "Security Misconfiguration",
            description = "Konfigurasi keamanan yang salah. Contoh: Fitur debug masih aktif di production, default password tidak diubah."
        )

        OWASPItem(
            number = "6",
            title = "Vulnerable and Outdated Components",
            description = "Menggunakan komponen/libraries yang memiliki celah keamanan. Contoh: Framework atau library yang tidak di-update."
        )

        OWASPItem(
            number = "7",
            title = "Identification and Authentication Failures",
            description = "Masalah dalam sistem login. Contoh: Password lemah, tidak ada 2FA, credential stuffing."
        )

        OWASPItem(
            number = "8",
            title = "Software and Data Integrity Failures",
            description = "Gagal memverifikasi integritas software/data. Contoh: Update software tanpa verifikasi signature."
        )

        OWASPItem(
            number = "9",
            title = "Security Logging and Monitoring Failures",
            description = "Kegagalan dalam logging dan monitoring. Contoh: Tidak mendeteksi serangan brute force karena logging tidak memadai."
        )

        OWASPItem(
            number = "10",
            title = "Server-Side Request Forgery (SSRF)",
            description = "Memaksa server untuk mengakses resource internal. Contoh: Memanipulasi parameter URL untuk mengakses internal API."
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Tips tambahan
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Tips Pencegahan",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Text(
                    text = "• Selalu update komponen sistem\n" +
                            "• Implementasi input validation\n" +
                            "• Gunakan prinsip least privilege\n" +
                            "• Enkripsi data sensitif\n" +
                            "• Audit keamanan berkala",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
    }
}

@Composable
fun OWASPItem(number: String, title: String, description: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp)
        ) {
            Text(
                text = number,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(end = 16.dp)
            )

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun OWASPTop10Preview() {
    AplikasiSederhanaTheme {
        OWASPTop10Content()
    }
}